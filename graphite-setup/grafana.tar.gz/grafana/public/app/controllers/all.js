/*! grafana - v2.5.0 - 2015-10-28
 * Copyright (c) 2015 Torkel Ödegaard; Licensed Apache-2.0 */

define(["./grafanaCtrl","./search","./inspectCtrl","./jsonEditorCtrl","./loginCtrl","./invitedCtrl","./signupCtrl","./resetPasswordCtrl","./sidemenuCtrl","./errorCtrl"],function(){});