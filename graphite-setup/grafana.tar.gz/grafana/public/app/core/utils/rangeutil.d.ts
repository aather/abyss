/// <reference path="../../../../public/app/headers/common.d.ts" />
import _ = require('lodash');
declare var _default: {
    getRelativeTimesList: (timepickerSettings: any, currentDisplay: any) => _.Dictionary<any[]>;
    describeTextRange: (expr: any) => any;
    describeTimeRange: (range: any) => any;
};
export = _default;
